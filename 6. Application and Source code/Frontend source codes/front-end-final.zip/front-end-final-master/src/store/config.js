const baseURL = 'https://leisure-tours-backend-heroku.herokuapp.com/webapi'

export default baseURL