const baseURL = 'http://localhost:8080/com.tourismapp/webapi'

export default baseURL